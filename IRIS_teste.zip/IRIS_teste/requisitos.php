<?php

require_once("helpers/base_dados.php");
require_once("helpers/funcoes.php");

// require_once("helpers/autor_helper.php");
// require_once("helpers/carousel_helper.php");
require_once("helpers/contactos_helper.php");
require_once("helpers/envios_helper.php");
require_once("helpers/home_helper.php");
require_once("helpers/iris_helper.php");
require_once("helpers/modelos_helper.php");
require_once("helpers/produtos_helper.php");


?>
