    <footer class="container-fluid p-0 m-0">
        <div class="row mx-2">
            <div class="col-12 border border-dark"></div>
            <div class="col-12">
                <h6 class="py-2">
                    Daniel Almeida
                    <br>
                    Site Sebastião Alves - Trabalho Final
                </h6>
            </div>
            <div class="col-12 border border-dark"></div>
        </div>
    </footer>
    <script src="../javascript/main.js"></script>
</body>

</html>