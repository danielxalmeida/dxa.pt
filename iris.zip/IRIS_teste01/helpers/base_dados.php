<?php

$pdo = new PDO("mysql:host=localhost;dbname=iris;charset=utf8mb4;","root","");

?>