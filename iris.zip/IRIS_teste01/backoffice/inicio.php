<?php

require_once("requisitos.php");

require_once("requisitosbackoffice.php");

$paginamain="inicio";

require("componentes/headerbackoffice.php");

require("mains/main$paginamain.php");

require("componentes/footerbackoffice.php");

?>