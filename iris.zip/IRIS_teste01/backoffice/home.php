<?php

require_once("requisitos.php");

require_once("backoffice/requisitosbackoffice.php");

$paginamain="home";

require("componentes/headerbackoffice.php");

require("mains/main$paginamain.php");

require("componentes/footerbackoffice.php");

?>