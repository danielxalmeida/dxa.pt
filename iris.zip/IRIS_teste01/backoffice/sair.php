<?php
require_once("requisitos.php");
logout();
?>