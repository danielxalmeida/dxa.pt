<?php

// $pdo = new PDO("mysql:host=localhost;dbname=iris;charset=utf8mb4;","root","");
$pdo = new PDO("mysql:host=www.danielxalmeida.pt;dbname=danielxa_iris;charset=utf8mb4;","danielxa_contact","gWN&HK^VwN71045?");

?>