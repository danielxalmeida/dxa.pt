<?php

require("componentes/header.php");
require("views/home_view.php");
require("componentes/footer.php");

?>