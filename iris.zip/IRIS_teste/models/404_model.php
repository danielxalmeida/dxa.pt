<?php

require("componentes/header.php");
require("views/404_view.php");
require("componentes/footer.php");

?>