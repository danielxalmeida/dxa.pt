var vista=document.querySelector("#fixview");
var menu=document.querySelector(".header");
vista.scrollIntoView();